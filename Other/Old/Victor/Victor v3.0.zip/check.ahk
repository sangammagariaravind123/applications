#Requires AutoHotkey v2.0

Sleep(3000)
CoordMode('Pixel', 'Screen')

if (ImageSearch(&helloX, &helloY, 0, 0, A_ScreenWidth, A_ScreenHeight, "*100 ticketwatchad.png")) {
    Click(helloX, helloY)
    Sleep(2000)
    Click(helloX, helloY)
    MsgBox "Yes"
    ExitApp
}
else {
    MsgBox "No"
}

^+Enter:: {
    ExitApp
}